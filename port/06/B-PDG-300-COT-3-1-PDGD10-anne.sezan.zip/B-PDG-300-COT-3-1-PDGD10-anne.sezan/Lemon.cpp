/*
** EPITECH PROJECT, 2024
** B-PDG-300-COT-3-1-PDGD10-anne.sezan
** File description:
** ACitrus.cpp
*/

#define IFRUIT
#include <string>
#include <iostream>
#include "AFruit.hpp"
#include "ACitrus.hpp"
#include "Lemon.hpp"

Lemon::Lemon() : ACitrus("lemon", 4) {}