/*
** EPITECH PROJECT, 2024
** B-PDG-300-COT-3-1-PDGD10-anne.sezan
** File description:
** Almond.cpp
*/

#ifndef IFruit
#define IFRUIT
#include <string>
#include <iostream>

Orange::Orange() : AFruit(), ACitrus("Orange", 4) {}