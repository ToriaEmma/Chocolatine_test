/*
** EPITECH PROJECT, 2024
** B-PDG-300-COT-3-1-PDGD10-anne.sezan
** File description:
** ANut.cpp
*/

#ifndef ANUT
#define ANUT
#include <string>
#include <iostream>
#include "AFruit.hpp"

class ANut : public AFruit
{
    protected:
    ANut(const std::string name, int vitamins);
    public:
    ~ANut() override = default;
};

#endif