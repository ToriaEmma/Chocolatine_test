/*
** EPITECH PROJECT, 2024
** B-PDG-300-COT-3-1-PDGD10-anne.sezan
** File description:
** Almond.cpp
*/

#ifndef AFRUIT
#define AFRUIT
#include <string>
#include <iostream>
#include "IFruit.hpp"

class AFruit : public IFruit {
    protected:
    unsigned int vitamins;
    std::string name;
    bool peel;

    public:
    AFruit(const std::string &name, unsigned int vitamins);
    virtual ~AFruit() = default;
    unsigned int getVitamins() const override;
    std::string getName() const override;
    bool isPeeled() const override;
    void peel() override;

};

#endif