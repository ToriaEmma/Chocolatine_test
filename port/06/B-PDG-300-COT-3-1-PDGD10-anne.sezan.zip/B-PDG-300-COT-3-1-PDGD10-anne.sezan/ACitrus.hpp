/*
** EPITECH PROJECT, 2024
** B-PDG-300-COT-3-1-PDGD10-anne.sezan
** File description:
** ACitrus.cpp
*/

#ifndef ACITRUS
#define ACITRUS
#include <string>
#include <iostream>
#include "AFruit.hpp"

class ACitrus : public AFruit
{
    public:
    ACitrus();
};

#endif