/*
** EPITECH PROJECT, 2024
** B-PDG-300-COT-3-1-PDGD10-anne.sezan
** File description:
** IFruit.cpp
*/

#ifndef ORANGE
#define ORANGE
#include <string>
#include <iostream>
#include "IFruit.hpp"
#include "AFruit.hpp"
#include "ACitrus.hpp"

class Orange : virtual public AFruit
{
    public:
    Orange();
};

#endif