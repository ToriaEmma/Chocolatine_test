/*
** EPITECH PROJECT, 2024
** B-PDG-300-COT-3-1-PDGD10-anne.sezan
** File description:
** IFruit.cpp
*/

#include <string>
#include <iostream>
#include "IFruit.hpp"
#include "AFruit.hpp"

std::ostream& operator<<(std::ostream& os, const IFruit& fruit)
{
    os << "[name: \"" << fruit.getName << "\", vitamins: " << std::fruit.getVitamins() << ", peeled:" << (fruit.isPeeled() ? "true": "false") << "]";
    return os;
}

