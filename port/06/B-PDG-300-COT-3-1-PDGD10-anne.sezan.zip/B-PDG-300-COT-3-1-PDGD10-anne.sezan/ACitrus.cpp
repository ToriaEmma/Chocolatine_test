/*
** EPITECH PROJECT, 2024
** B-PDG-300-COT-3-1-PDGD10-anne.sezan
** File description:
** ACitrus.cpp
*/

#include <string>
#include <iostream>
#include "AFruit.hpp"

ACitrus::ACitrus(const std::string name, unsigned int vitamins) : AFruit(name, vitamins) {}