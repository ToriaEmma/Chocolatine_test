/*
** EPITECH PROJECT, 2024
** B-PDG-300-COT-3-1-PDGD10-anne.sezan
** File description:
** Almond.cpp
*/

#ifndef ALMOND
#define ALMOND
#include <string>
#include <iostream>
#include "ANut.hpp"

class Almond : public ANut
{
    public:
    Almond();
};

#endif