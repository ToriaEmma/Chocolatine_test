/*
** EPITECH PROJECT, 2024
** B-PDG-300-COT-3-1-PDGD10-anne.sezan
** File description:
** ACitrus.cpp
*/

#include <string>
#include <iostream>
#include "IFruit.hpp"
#include "AFruit.hpp"
#include "ACitrus.hpp"
#include "Almond.hpp"
#include "ABerry.hpp"
#include "ANut.hpp"

int main(void)
{
    Orange o;
    Strawberry s;
    const Almond a;
    IFruit& f = o;

    std::cout << o.getName() << ": " << o.getVitamins() << " vitamins" << std::endl;
    std::cout << s << std::endl;
    std::cout << a << std::endl;

    o.peel();
    std::cout << f << std::endl;

    return 0;
}
