/*
** EPITECH PROJECT, 2024
** B-PDG-300-COT-3-1-PDGD10-anne.sezan
** File description:
** ABerry.cpp
*/

#ifndef ABERRY
#define ABERRY
#include <string>
#include <iostream>
#include "AFruit.hpp"

class ABerry : public AFruit
{
public:
    ABerry();
};

#endif