/*
** EPITECH PROJECT, 2024
** B-PDG-300-COT-3-1-PDGD10-anne.sezan
** File description:
** ACitrus.cpp
*/


#include "ABerry.hpp"

ABerry::Strawberry() : AFruit(), ABerry("Strawberry", 6) {}