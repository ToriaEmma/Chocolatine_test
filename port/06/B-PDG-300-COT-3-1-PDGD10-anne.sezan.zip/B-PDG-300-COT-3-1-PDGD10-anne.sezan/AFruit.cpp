/*
** EPITECH PROJECT, 2024
** B-PDG-300-COT-3-1-PDGD10-anne.sezan
** File description:
** AFruit.cpp
*/

#include <string>
#include <iostream>
#include "AFruit.hpp"
#include "AFruit.hpp"

AFruit::AFruit(const std::string &name, unsigned int vitamins) : name(name), viamins(vitamins), peel(false) {}

unsigned int AFruit::getVitamins() const
{
    return peel ? vitamins : 0;
}

std::string AFruit::getName() const
{
    return name;
}

bool AFruit::isPeeled() const
{
    return peel;
}

void AFruit::peel()
{
    if (peel != 0) {
        peel = true;
    }
}

